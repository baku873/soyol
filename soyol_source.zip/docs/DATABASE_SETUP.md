# Database Setup Guide (Өгөгдлийн сангийн тохиргоо)

## ⚠️ Одоогийн асуудал

`.env` файл амжилттай үүсгэгдсэн, гэхдээ өгөгдлийн сан холбогдоогүй байна.

---

## 🎯 Шийдэл - 2 сонголт

### **Сонголт 1: Neon Database (Хамгийн хялбар, үнэгүй) ✅ САНАЛ**

Neon бол онлайн PostgreSQL database - суулгах шаардлагагүй!

1. **Neon.tech рүү очих**: https://neon.tech
2. **Үнэгүй бүртгүүлэх** (GitHub эсвэл Google-ээр)
3. **New Project үүсгэх**
4. **Connection String авах** - Энэ маягтай байна:
   ```
   postgresql://username:password@ep-cool-name.region.aws.neon.tech/neondb?sslmode=require
   ```

5. **`.env` файлыг шинэчлэх**:
   ```env
   DATABASE_URL="таны-connection-string-энд"
   DIRECT_URL="таны-connection-string-энд"
   ```

6. **Database схемийг үүсгэх**:
   ```bash
   npx prisma db push
   ```

---

### **Сонголт 2: Local PostgreSQL (Компьютер дээрээ суулгах)**

#### Windows дээр PostgreSQL суулгах:

1. **PostgreSQL татах**:
   - Очих: https://www.postgresql.org/download/windows/
   - Installer татаж суулгах
   - Password тохируулах (жишээ: `postgres123`)

2. **Суулгасны дараа `.env` засах**:
   ```env
   DATABASE_URL="postgresql://postgres:postgres123@localhost:5432/soyol_db"
   DIRECT_URL="postgresql://postgres:postgres123@localhost:5432/soyol_db"
   ```

3. **Database үүсгэх**:
   ```bash
   # PowerShell дээр
   npx prisma db push
   ```

---

## 🚀 Одоо юу хийх вэ?

### Хэрвээ database холбохыг хүсэхгүй бол:

**Development mode-оор ажиллуулах (Database-гүйгээр)**:

```bash
npm run dev
```

Таны website ажиллах болно, гэхдээ:
- ❌ Login/Register ажиллахгүй (database шаардлагатай)
- ❌ Order хадгалагдахгүй
- ✅ Бусад бүх зүйл ажиллана (homepage, cart, wishlist)

---

## 📝 Хурдан шийдэл - Neon Database ашиглах (5 минут)

```bash
# 1. Neon.tech-с connection string авсны дараа:
# .env файл дахь DATABASE_URL болон DIRECT_URL-г солих

# 2. Database schemas үүсгэх:
npx prisma db push

# 3. Development server эхлүүлэх:
npm run dev

# ✅ Бүх зүйл ажиллаж эхэлнэ!
```

---

## ✅ Одоогийн `.env` файлын байдал

Таны `.env` файл үүссэн ба дараах утгууд оруулсан:
- ✅ `DATABASE_URL` - Одоо local database руу заасан (сольж болно)
- ✅ `DIRECT_URL` - Одоо local database руу заасан (сольж болно)
- ✅ `NEXTAUTH_URL` - Бэлэн
- ✅ `NEXTAUTH_SECRET` - Автоматаар үүссэн (бэлэн)
- ⚠️ `GOOGLE_CLIENT_ID` - Хоосон (зөвхөн Google login хэрэг бол л)
- ⚠️ `GOOGLE_CLIENT_SECRET` - Хоосон (зөвхөн Google login хэрэг бол л)

---

## 🎯 Миний санал

1. **Neon.tech ашиглах** (5 минут)
2. **Connection string авах**
3. **`.env` файлд хуулах**
4. **`npx prisma db push` ажиллуулах**
5. **`npm run dev` эхлүүлэх**

Бүх зүйл ажиллах болно! 🚀

---

## ❓ Тусламж хэрэгтэй бол:

1. Neon database үүсгэх дээр бэрхшээлтэй бол - хэлээрэй
2. Local PostgreSQL суулгах дээр бэрхшээлтэй бол - хэлээрэй
3. Database-гүйгээр ажиллуулах гэж байгаа бол - `npm run dev` хийж болно

---

Одоо юу хийх вэ? 🤔
