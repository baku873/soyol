'use client';

import { Loader2 } from 'lucide-react';
import { useState } from 'react';

interface SocialAuthButtonsProps {
  mode: 'signIn' | 'signUp';
  /** Relative path after OAuth (e.g. `/dashboard` or `?redirect=` from login). */
  oauthRedirect?: string;
}

// Google icon SVG
function GoogleIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" />
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
    </svg>
  );
}

// Facebook icon SVG
function FacebookIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="#1877F2">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  );
}

export default function SocialAuthButtons({ mode, oauthRedirect = '/dashboard' }: SocialAuthButtonsProps) {
  const [loadingProvider, setLoadingProvider] = useState<'google' | 'facebook' | null>(null);

  const googleStartUrl = `/api/auth/google?redirect=${encodeURIComponent(oauthRedirect)}`;
  const facebookStartUrl = `/api/auth/facebook?redirect=${encodeURIComponent(oauthRedirect)}`;

  return (
    <div className="space-y-3">
      {/* Divider */}
      <div className="flex items-center gap-3 my-5">
        <div className="flex-1 h-px bg-slate-200" />
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.15em]">ЭСВЭЛ</span>
        <div className="flex-1 h-px bg-slate-200" />
      </div>

      {/* Google button (manual OAuth redirect) */}
      <button
        type="button"
        disabled={!!loadingProvider}
        onClick={() => {
          setLoadingProvider('google');
          window.location.href = googleStartUrl;
        }}
        className="w-full flex items-center justify-center gap-3 py-3.5 px-4 bg-white border border-sky-200/90 hover:border-sky-300 hover:bg-slate-50/80 rounded-2xl transition-all disabled:opacity-60 disabled:cursor-not-allowed font-bold text-sm text-[#0f172a] shadow-sm"
      >
        {loadingProvider === 'google' ? <Loader2 className="w-5 h-5 animate-spin" /> : <GoogleIcon />}
        Google-ээр {mode === 'signIn' ? 'нэвтрэх' : 'бүртгүүлэх'}
      </button>

      {/* Facebook button (manual OAuth redirect) */}
      <button
        type="button"
        onClick={() => {
          setLoadingProvider('facebook');
          window.location.href = facebookStartUrl;
        }}
        disabled={!!loadingProvider}
        className="w-full flex items-center justify-center gap-3 py-3.5 px-4 bg-[#1877F2] hover:bg-[#166FE5] rounded-2xl transition-all disabled:opacity-60 disabled:cursor-not-allowed font-bold text-sm text-white shadow-sm"
      >
        {loadingProvider === 'facebook' ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <FacebookIcon />
        )}
        Facebook-ээр {mode === 'signIn' ? 'нэвтрэх' : 'бүртгүүлэх'}
      </button>
    </div>
  );
}
