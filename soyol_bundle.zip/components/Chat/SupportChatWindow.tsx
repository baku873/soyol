'use client';

import { useState, useRef, useEffect } from 'react';
import { Send, ArrowLeft, Loader2 } from 'lucide-react';
import useSWR from 'swr';
import { useUser } from '../../context/AuthContext';
import { useTranslation } from '../../hooks/useTranslation';

interface SupportMessage {
    _id: string;
    senderId: string;
    senderType: 'user' | 'admin';
    body: string;
    createdAt: string;
}

interface SupportChatWindowProps {
    conversationId: string;
    onBack: () => void;
}

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function SupportChatWindow({ conversationId, onBack }: SupportChatWindowProps) {
    const { user } = useUser();
    const { t } = useTranslation();
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [sending, setSending] = useState(false);

    // Provide a minimal user-like object for guests if needed, but senderId matching will rely on the real userId
    // Wait, the new API uses MongoDB ObjectId for user.id.
    const effectiveUserId = user?.id;

    const { data, mutate } = useSWR<{ messages: SupportMessage[] }>(
        `/api/messages/conversations/${conversationId}/messages`,
        fetcher,
        { refreshInterval: 5000 } // Polling every 5 seconds
    );

    const messages = data?.messages || [];

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || sending) return;

        setSending(true);
        try {
            await fetch(`/api/messages/conversations/${conversationId}/messages`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: newMessage,
                }),
            });
            setNewMessage('');
            mutate(); // Refresh messages immediately
        } catch (error) {
            console.error('Failed to send message:', error);
        } finally {
            setSending(false);
        }
    };

    return (
        <div className="flex-1 flex flex-col h-full bg-transparent relative">
            {/* Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-slate-800/50 backdrop-blur-md">
                <div className="flex items-center gap-3">
                    <button onClick={onBack} className="p-2 -ml-2 text-slate-400 hover:text-white rounded-xl transition-colors">
                        <ArrowLeft className="w-5 h-5" strokeWidth={1.2} />
                    </button>
                    <div>
                        <h3 className="font-bold text-white leading-tight">Тусламжийн баг</h3>
                        <div className="text-xs text-slate-400 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                            Онлайн
                        </div>
                    </div>
                </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {!data && (
                    <div className="flex justify-center items-center h-full">
                        <Loader2 className="w-6 h-6 text-[#FF5000] animate-spin" />
                    </div>
                )}
                {messages.map((msg) => {
                    const isMe = msg.senderType === 'user';

                    return (
                        <div key={msg._id.toString()} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[80%] rounded-2xl px-4 py-2 shadow-sm ${isMe
                                ? 'bg-[#FF5000] text-white rounded-tr-none'
                                : 'bg-slate-800 text-slate-200 rounded-tl-none border border-white/5'
                                }`}>
                                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.body}</p>
                                <span className={`text-[10px] mt-1 block text-right ${isMe ? 'text-white/60' : 'text-slate-500'}`}>
                                    {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                            </div>
                        </div>
                    );
                })}
                <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-4 border-t border-white/10 bg-slate-900/50 backdrop-blur-md">
                <div className="flex gap-2">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder={t('chat', 'typeMessage')}
                        className="flex-1 bg-slate-800 border-none rounded-2xl px-4 py-3 text-white placeholder-slate-500 focus:ring-1 focus:ring-[#FF5000]/50 text-sm outline-none"
                    />
                    <button
                        type="submit"
                        disabled={!newMessage.trim() || sending}
                        className="p-3 bg-[#FF5000] hover:bg-[#E64500] text-white rounded-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-orange-500/20 active:scale-95"
                    >
                        <Send className="w-5 h-5" strokeWidth={1.2} />
                    </button>
                </div>
            </form>
        </div>
    );
}
